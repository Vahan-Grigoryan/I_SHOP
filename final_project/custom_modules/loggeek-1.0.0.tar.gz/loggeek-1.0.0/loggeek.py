from datetime import datetime 
from string import Template


class Logger:
    def __init__(self, file: str, level: str, formatter: str | None = None):
        self.file = file
        self.level = level.upper()
        #%Y-%m-%d at %H:%M:%S
        #self.formatter = formatter if formatter else '${level} ${time:%Y-%m-%d at %H:%M:%S} | ${log}'


    #def write_formatted_log(self, log_level, log):
    #   formatter = Template(self.formatter)
    #   string_identifiers = formatter.get_identifiers()
    #   formatter.subtitute(level=log_level, )


    def allow_by_loglevel(self, write_level):
        availability_for_each_level = {
            'DEBUG':{
                'DEBUG': True,
                'INFO': True,
                'ERROR': True,
            },
            'INFO':{
                'INFO': True,
                'ERROR': True,
            },
            'ERROR':{
                'ERROR': True,
            },
        }
        
        return availability_for_each_level[self.level].get(write_level)


    def debug(self, msg):
        if not self.allow_by_loglevel('DEBUG'): return

        with open(self.file, 'a') as f:
            f.write(f"DEBUG {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')} | {msg}\n")
            

    def info(self, msg):
        if not self.allow_by_loglevel('INFO'): return

        with open(self.file, 'a') as f:
            f.write(f"INFO {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')} | {msg}\n")


    def error(self, msg):
        if not self.allow_by_loglevel('ERROR'): return

        with open(self.file, 'a') as f:
            f.write(f"ERROR {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')} | {msg}\n")
