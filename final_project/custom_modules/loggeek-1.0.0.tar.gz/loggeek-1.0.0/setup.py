from setuptools import setup, find_packages


setup(
    name="loggeek",
    version="1.0.0",
)
